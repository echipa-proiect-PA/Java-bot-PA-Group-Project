# Membri
- Trifan Bogdan Cristian, 322 CD
- Valerica-Madalin Spoiala, 342 C4



to setup the project run:

./setup.h

after running this command the game binaries can be found inside /game_binaries directory

